# Email-Table-Example
A simple JavaFX project that keeps a list of email contacts using an SQLite database
