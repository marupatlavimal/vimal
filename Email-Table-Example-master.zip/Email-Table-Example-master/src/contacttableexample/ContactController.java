/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contacttableexample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Person;
import util.DBUtil;

/**
 *
 * @author Thomas
 */
public class ContactController implements Initializable {
    private final DBUtil db = new DBUtil();
    private ContactTableExample contactTableExample;
    private Stage dialogStage;
    private Person editPerson;
    
    @FXML private TableView<Person> personTable;
    private ObservableList<Person> personListData = FXCollections.observableArrayList();
    
    @FXML private TableColumn<Person, String> firstNameCol;
    @FXML private TableColumn<Person, String> lastNameCol;
    @FXML private TableColumn<Person, String> emailCol;
    
    @FXML private TextField firstNameTF;
    @FXML private TextField lastNameTF;
    @FXML private TextField emailTF;
    
    @FXML private Button addPersonButton;
    
    /**
     * 
     * @param url
     * @param rb 
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initPersonTable();
        setPersonTable();
    } 
    
    /**
     * Handles the ability to add a person to the database
     * and the ability to edit a person in the table.  To add a person
     * at least one of the fields has to be filled in
     * @param event 
     */
    @FXML
    private void addPerson(ActionEvent event) {
        String fname = firstNameTF.getText();
        String lname = lastNameTF.getText();
        String email = emailTF.getText();
        
        if(addPersonButton.getText().equals("Add")) {
            if(!fname.equals("") || !lname.equals("") || !email.equals("")) {
                Person person = new Person(fname, lname, email);
                db.addPerson(person);
                setPersonTable();

                clearFields();
            }
        } else {
            if(!fname.equals("") || !lname.equals("") || !email.equals("")) {
                editPerson.setFirstName(fname);
                editPerson.setLastName(lname);
                editPerson.setEmail(email);
                
                db.updatePerson(editPerson);
                setPersonTable();

                clearFields();
            }
        }
    }
    
    /**
     * Whenever a Person in the table is left clicked, set the textfields
     * to them.
     * @param event 
     */
    @FXML
    private void personClicked(MouseEvent event) {
        if(event.getButton() == MouseButton.PRIMARY) {
            Person person = personTable.getSelectionModel().getSelectedItem();
            if(person != null) {
                setFields(person);
            }
        } else if(event.getButton() == MouseButton.SECONDARY) {
            
        }
    }
    
    /**
     * Set selected person to the TextFields to allow them to be
     * edited
     * @param person 
     */
    private void setFields(Person person) {
        editPerson = person;
        addPersonButton.setText("Update");
        firstNameTF.setText(editPerson.getFirstName());
        lastNameTF.setText(editPerson.getLastName());
        emailTF.setText(editPerson.getEmail());
    }
    
    /**
     * Clear the textfields to allow another person to be added to the table
     */
    private void clearFields() {
        editPerson = null;
        addPersonButton.setText("Add");
        firstNameTF.setText("");
        lastNameTF.setText("");
        emailTF.setText("");
    }
    
    /**
     * Allow access to the main class
     * @param cte 
     */
    public void setContactTable(ContactTableExample cte) {
        contactTableExample = cte;
    }
    
    /**
     * Allow access to the main class' stage
     * @param stage 
     */
    public void setDialogStage(Stage stage) {
        dialogStage = stage;
    }
    
    /**
     * Set the column's first and bind the width of the columns to size
     * of the table
     */
    private void initPersonTable() {
        firstNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
        emailCol.setCellValueFactory(new PropertyValueFactory<Person, String>("email"));
	    
        firstNameCol.prefWidthProperty().bind(personTable.widthProperty().multiply(0.30));
        lastNameCol.prefWidthProperty().bind(personTable.widthProperty().multiply(0.30));
        emailCol.prefWidthProperty().bind(personTable.widthProperty().multiply(0.38));
    }
    
    /**
     * Fetches the person from the database and set data to the table
     */
    private void setPersonTable() {
        personListData.clear();
        personListData = db.getPersonTable();
        personTable.setItems(personListData);
    }
}
