/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thomas
 */
public class DBSchema {
    public static final class PersonTable {
    public static final String NAME = "PersonTable";

    public static final class Cols {
        public static final String ID = "RowID";			
        public static final String FIRST_NAME = "FirstName";				
        public static final String LAST_NAME = "LastName";		
        public static final String EMAIL = "Email";	
            
        public static final String SQL_TABLE = "CREATE TABLE IF NOT EXISTS " + PersonTable.NAME
            + "  (" + PersonTable.Cols.ID + "           	INTEGER PRIMARY KEY,"
            + "   " + PersonTable.Cols.FIRST_NAME + "          	TEXT,"
            + "   " + PersonTable.Cols.LAST_NAME + "           	TEXT,"
            + "   " + PersonTable.Cols.EMAIL + "         TEXT)";
        }
    }
}
