/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person;
import util.DBSchema.PersonTable;

/**
 *
 * @author Thomas
 */
public class DBUtil {
    public DBUtil() {
        Connection con = connect();
        try {	
            /**
             * Check to see if the Tables exist or not
             */
            Statement stmt = con.createStatement();
            stmt.execute(DBSchema.PersonTable.Cols.SQL_TABLE);	
            stmt.close();    
        } catch(Exception e) {
          
        }
    }
    
    public Connection connect() {
    	try {
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:src/resources/ContactDB.sqlite");
            return conn;
	} catch(Exception e) {
            return null;
	}
    }
    
    public ObservableList<Person> getPersonTable() {
	ObservableList<Person> index = FXCollections.observableArrayList();
	Connection con = connect();
	
        try {
            String sql = "SELECT " + PersonTable.Cols.ID + ", " + 
                    PersonTable.Cols.FIRST_NAME + ", " + 
                    PersonTable.Cols.LAST_NAME + ", " +
                    PersonTable.Cols.EMAIL + 
                    " FROM " + PersonTable.NAME; 
	
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
			
            while(result.next()) {
                int id = result.getInt(PersonTable.Cols.ID);
                String fname = result.getString(PersonTable.Cols.FIRST_NAME);
                String lname = result.getString(PersonTable.Cols.LAST_NAME);
                String email = result.getString(PersonTable.Cols.EMAIL);
                
		Person person = new Person(fname, lname, email);
                person.setID(id);
                
                index.add(person);
            }
            
            statement.close();
            return index;
			
	} catch(Exception e) {
            return index;
	} finally {
            try {
                con.close();
            } catch (SQLException e) {

            }
	}
    }
    
    public void addPerson(Person person) {
        Connection con = connect();
	
        try {
            PreparedStatement stmt = con
                .prepareStatement("INSERT into " + PersonTable.NAME + " (" + 
                    PersonTable.Cols.FIRST_NAME + ", " + 
                    PersonTable.Cols.LAST_NAME + ", " + 
                    PersonTable.Cols.EMAIL +
                    " ) VALUES(?, ?, ?)");

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());
            stmt.executeUpdate();
            stmt.close();
        } catch(Exception ex) {

	}finally{
            try {
                con.close();
            } catch(SQLException ex) {

            }
	}
    }
    
    public void updatePerson(Person person) {
	Connection con = connect();

	try {
            String sql = "UPDATE " + PersonTable.NAME + " set " + 
	    	PersonTable.Cols.FIRST_NAME + " = ?, " +
                PersonTable.Cols.LAST_NAME + " = ?, " +
	    	PersonTable.Cols.EMAIL + " = ? WHERE " +
	    	PersonTable.Cols.ID + " = ?";
	    	
            PreparedStatement stmt = con
                .prepareStatement(sql);

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());
            stmt.setInt(4, person.getID());	
            stmt.executeUpdate();
			
            stmt.close();
        } catch (Exception e) { 

	} finally {
            try {
                con.close();
            } catch (SQLException e) {

            }
	}
    }
}
